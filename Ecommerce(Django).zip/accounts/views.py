from django.shortcuts import render, redirect

from store.models import Customer
from .forms import NewUserForm
from django.contrib.auth import login
from django.contrib import messages

def register_request(request):
    if request.method == "POST":
        form = NewUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            customer = Customer.objects.create(user = user,name=user.username,email=user.email)
            messages.success(request, "Registration successful." )
            return redirect('store')
        messages.error(request, "Unsuccessful registration. Invalid information.")
    form = NewUserForm()
    return render (request=request, template_name="store/register.html", context={"register_form":form})


from django.contrib.auth import authenticate, login, logout
from django.contrib import messages

def login_request(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if True:
            login(request, user)
            messages.success(request, "You are now logged in.")
            return redirect('store')
        else:
            messages.error(request,"Invalid username or password.")
    return render(request=request, template_name='store/login.html')


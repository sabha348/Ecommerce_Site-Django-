from django.contrib.auth import views as auth_views
from django.urls import path

from . import views

urlpatterns = [
	#Leave as empty string for base url
	path('', views.store, name="store"),
	path('cart/', views.cart, name="cart"),
	path('checkout/', views.checkout, name="checkout"),

	path('update_item/', views.updateItem, name="update_item"),
    path('process_order/', views.processOrder, name="process_order"),
    
	path('register', views.register_request, name="register_request"),
    path('login', views.login_request, name="login_request"),
    
	path('password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),

	path('view_product/<int:id>/', views.view_product, name="view_product"),
    
	path('logout/', views.logout_request, name="logout"),
    


]